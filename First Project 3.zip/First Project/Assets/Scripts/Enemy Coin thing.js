﻿/*This is to collect coins and them
disappear ater they are picked up*/
#pragma strict

public var points : int = 5;
public var pickedUpBy : String = "Enemy";
/*
Public varibles will
show up in unity editor*/

function OnTriggerEnter2D(other : Collider2D) //checks for collisions
{
 if(other.CompareTag(pickedUpBy) ) //if there is collision, do these two things:
  {
    Debug.Log("Coins! Worth" + points + "points!"); //give 5 points

    Destroy(gameObject); //destory oneself

    }

}